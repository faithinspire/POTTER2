# 🏗️ System Overview - Millennium Potter

Complete visual guide to the platform architecture.

## 🎯 System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     CLIENT LAYER                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   Admin      │  │  Sub-Admin   │  │    Agent     │     │
│  │  Dashboard   │  │  Dashboard   │  │  Dashboard   │     │
│  │              │  │              │  │              │     │
│  │  15+ Pages   │  │  12+ Pages   │  │  10+ Pages   │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│         │                  │                  │            │
│         └──────────────────┼──────────────────┘            │
│                            │                               │
│                   React Application                        │
│                   (Vite + TypeScript)                      │
│                            │                               │
└────────────────────────────┼───────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                   SUPABASE BACKEND                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │     Auth     │  │   Database   │  │   Realtime   │     │
│  │              │  │              │  │              │     │
│  │  - Login     │  │  - PostgreSQL│  │  - Live Sync │     │
│  │  - Sessions  │  │  - RLS       │  │  - Webhooks  │     │
│  │  - Roles     │  │  - Triggers  │  │  - Events    │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                    DATA LAYER                               │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ Branches │  │  Users   │  │Customers │  │  Loans   │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
│                                                             │
│  ┌──────────┐  ┌──────────┐                                │
│  │Guarantors│  │ Payments │                                │
│  └──────────┘  └──────────┘                                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 👥 User Roles & Access

```
┌─────────────────────────────────────────────────────────────┐
│                        ADMIN                                │
│                    (Global Access)                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ✅ View all branches                                       │
│  ✅ Manage all users                                        │
│  ✅ View all loans                                          │
│  ✅ View all transactions                                   │
│  ✅ Generate reports                                        │
│  ✅ Export data                                             │
│  ✅ Branch comparison                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
                             │
                ┌────────────┴────────────┐
                │                         │
                ▼                         ▼
┌──────────────────────────┐  ┌──────────────────────────┐
│      SUB-ADMIN           │  │      SUB-ADMIN           │
│   (Igando Branch)        │  │  (Abule-Egba Branch)     │
├──────────────────────────┤  ├──────────────────────────┤
│                          │  │                          │
│  ✅ Branch dashboard     │  │  ✅ Branch dashboard     │
│  ✅ Manage agents        │  │  ✅ Manage agents        │
│  ✅ Approve loans        │  │  ✅ Approve loans        │
│  ✅ View customers       │  │  ✅ View customers       │
│  ✅ Branch analytics     │  │  ✅ Branch analytics     │
│  ❌ Other branch data    │  │  ❌ Other branch data    │
│                          │  │                          │
└──────────────────────────┘  └──────────────────────────┘
         │                              │
    ┌────┴────┐                    ┌────┴────┐
    │         │                    │         │
    ▼         ▼                    ▼         ▼
┌────────┐ ┌────────┐          ┌────────┐ ┌────────┐
│ Agent1 │ │ Agent2 │          │ Agent1 │ │ Agent2 │
│ Igando │ │ Igando │          │ Abule  │ │ Abule  │
├────────┤ ├────────┤          ├────────┤ ├────────┤
│        │ │        │          │        │ │        │
│ ✅ Own │ │ ✅ Own │          │ ✅ Own │ │ ✅ Own │
│ custo- │ │ custo- │          │ custo- │ │ custo- │
│ mers   │ │ mers   │          │ mers   │ │ mers   │
│ ✅ Own │ │ ✅ Own │          │ ✅ Own │ │ ✅ Own │
│ loans  │ │ loans  │          │ loans  │ │ loans  │
│ ✅ Own │ │ ✅ Own │          │ ✅ Own │ │ ✅ Own │
│ pay-   │ │ pay-   │          │ pay-   │ │ pay-   │
│ ments  │ │ ments  │          │ ments  │ │ ments  │
│ ❌ Other│ │ ❌ Other│          │ ❌ Other│ │ ❌ Other│
│ agents │ │ agents │          │ agents │ │ agents │
└────────┘ └────────┘          └────────┘ └────────┘
```

## 🔄 Data Flow

### Customer Registration Flow
```
Agent Dashboard
      │
      ▼
┌─────────────────┐
│ Customer Form   │
│ - Personal Info │
│ - ID Details    │
│ - Guarantors    │
└─────────────────┘
      │
      ▼
   Validate
      │
      ▼
┌─────────────────┐
│ Save to DB      │
│ - customers     │
│ - guarantors    │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ Auto-Link       │
│ - To Agent      │
│ - To Branch     │
│ - To Sub-Admin  │
└─────────────────┘
```

### Loan Application Flow
```
Agent
  │
  ▼
Submit Loan Application
  │
  ├─ Customer ID
  ├─ Amount
  ├─ Interest Rate
  ├─ Duration
  │
  ▼
Auto-Calculate Weekly Payment
  │
  ▼
Set Status: PENDING
  │
  ▼
Auto-Assign to Sub-Admin
  │
  ▼
Notify Sub-Admin
  │
  ▼
Sub-Admin Reviews
  │
  ├─ Approve ──────┐
  │                │
  ├─ Reject ───────┤
  │                │
  ▼                ▼
Status: APPROVED   Status: REJECTED
  │                │
  ▼                ▼
Notify Agent       Notify Agent
  │
  ▼
Generate Payment Schedule
  │
  ▼
Status: ACTIVE
```

### Payment Recording Flow
```
Agent Dashboard
      │
      ▼
Weekly Payment Grid
      │
      ▼
Mark Payment (Checkbox)
      │
      ▼
┌─────────────────┐
│ Calculate       │
│ - Amount Paid   │
│ - Amount Due    │
└─────────────────┘
      │
      ▼
┌─────────────────┐
│ Auto-Set Status │
│ - Paid (100%)   │
│ - Partial (<100%)│
│ - Overdue (late)│
│ - Unpaid (0%)   │
└─────────────────┘
      │
      ▼
Save to Database
      │
      ▼
┌─────────────────┐
│ Real-Time Sync  │
│ - Agent view    │
│ - Sub-Admin view│
│ - Admin view    │
└─────────────────┘
```

## 🗄️ Database Relationships

```
branches
    │
    ├──────────────┐
    │              │
    ▼              ▼
  users        customers
    │              │
    │              ├─────────┐
    │              │         │
    │              ▼         ▼
    │          guarantors  loans
    │                        │
    │                        ▼
    └──────────────────> payments
```

### Detailed Relationships
```
branches (1) ──< (many) users
branches (1) ──< (many) customers
branches (1) ──< (many) loans
branches (1) ──< (many) payments

users (1) ──< (many) customers [as agent]
users (1) ──< (many) loans [as agent]
users (1) ──< (many) loans [as subadmin]
users (1) ──< (many) payments [as agent]

customers (1) ──< (many) guarantors
customers (1) ──< (many) loans
customers (1) ──< (many) payments

loans (1) ──< (many) payments
```

## 🔐 Security Layers

```
┌─────────────────────────────────────────────────────────────┐
│                    SECURITY LAYERS                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Layer 1: Authentication                                    │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Supabase Auth                                         │ │
│  │ - Email/Password                                      │ │
│  │ - JWT Tokens                                          │ │
│  │ - Session Management                                  │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  Layer 2: Role-Based Access                                │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ User Roles                                            │ │
│  │ - Admin (global)                                      │ │
│  │ - Sub-Admin (branch)                                  │ │
│  │ - Agent (own data)                                    │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  Layer 3: Row Level Security                               │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ RLS Policies                                          │ │
│  │ - Branch-based filtering                              │ │
│  │ - Agent-based filtering                               │ │
│  │ - Automatic enforcement                               │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  Layer 4: Data Validation                                  │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Database Constraints                                  │ │
│  │ - Check constraints                                   │ │
│  │ - Foreign keys                                        │ │
│  │ - Unique constraints                                  │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📊 Dashboard Structure

### Admin Dashboard (15+ Pages)
```
Admin Dashboard
├── Overview
│   ├── Global KPIs
│   ├── Branch Comparison
│   └── Recent Activity
├── Branch Management
│   ├── Branch List
│   └── Branch Details
├── User Management
│   ├── All Users
│   ├── Add User
│   └── Edit User
├── Loan Management
│   ├── All Loans
│   ├── Pending Approvals
│   ├── Active Loans
│   └── Loan Details
├── Transaction Monitoring
│   ├── All Transactions
│   ├── Real-Time Feed
│   └── Transaction Details
└── Reports & Analytics
    ├── Performance Reports
    ├── Collection Reports
    ├── Agent Rankings
    └── Data Export
```

### Sub-Admin Dashboard (12+ Pages)
```
Sub-Admin Dashboard
├── Branch Overview
│   ├── Branch KPIs
│   ├── Weekly Trends
│   └── Recent Activity
├── Agent Management
│   ├── Agent List
│   ├── Add Agent
│   ├── Agent Performance
│   └── Agent Details
├── Customer Management
│   ├── Customer List
│   ├── Customer Details
│   └── Customer Search
├── Loan Approvals
│   ├── Pending Queue
│   ├── Review Loan
│   ├── Approved Loans
│   └── Rejected Loans
└── Branch Analytics
    ├── Collection Trends
    ├── Loan Performance
    └── Agent Leaderboard
```

### Agent Dashboard (10+ Pages)
```
Agent Dashboard
├── Overview
│   ├── Personal KPIs
│   ├── Today's Tasks
│   └── Performance Metrics
├── Customer Management
│   ├── Register Customer
│   ├── Customer List
│   └── Customer Details
├── Loan Management
│   ├── Apply for Loan
│   ├── My Loans
│   └── Loan Status
├── Payment Tracking
│   ├── Weekly Payment Grid
│   ├── Daily Collection
│   └── Payment History
└── Performance
    ├── My Stats
    ├── Targets
    └── Achievements
```

## 🔄 Real-Time Features

```
┌─────────────────────────────────────────────────────────────┐
│                  REAL-TIME UPDATES                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Event: Payment Recorded                                    │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Agent marks payment ✓                                 │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Database Update                                       │ │
│  │ - payments table                                      │ │
│  │ - Auto-calculate status                               │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Supabase Realtime                                     │ │
│  │ - Broadcast change                                    │ │
│  │ - Notify subscribers                                  │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│          ┌───────────────┼───────────────┐                 │
│          │               │               │                 │
│          ▼               ▼               ▼                 │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐         │
│  │   Agent     │ │  Sub-Admin  │ │    Admin    │         │
│  │  Dashboard  │ │  Dashboard  │ │  Dashboard  │         │
│  │             │ │             │ │             │         │
│  │ ✅ Updated  │ │ ✅ Updated  │ │ ✅ Updated  │         │
│  └─────────────┘ └─────────────┘ └─────────────┘         │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 🎨 Component Architecture

```
App.tsx
  │
  ├─ BackgroundAnimation
  │   └─ Floating Currencies
  │
  ├─ Router
  │   │
  │   ├─ Public Routes
  │   │   ├─ Login
  │   │   └─ Forgot Password
  │   │
  │   └─ Protected Routes
  │       │
  │       ├─ Admin Routes
  │       │   ├─ AdminLayout
  │       │   │   ├─ Navbar
  │       │   │   └─ Sidebar
  │       │   └─ Admin Pages
  │       │
  │       ├─ Sub-Admin Routes
  │       │   ├─ SubAdminLayout
  │       │   │   ├─ Navbar
  │       │   │   └─ Sidebar
  │       │   └─ Sub-Admin Pages
  │       │
  │       └─ Agent Routes
  │           ├─ AgentLayout
  │           │   ├─ Navbar
  │           │   └─ Sidebar
  │           └─ Agent Pages
  │
  └─ Shared Components
      ├─ Card
      ├─ Button
      ├─ Modal
      ├─ Table
      ├─ Input
      ├─ Badge
      └─ LoadingSpinner
```

## 📱 Responsive Design

```
Desktop (1920px+)
┌─────────────────────────────────────────────────────────────┐
│ Navbar                                                      │
├──────────┬──────────────────────────────────────────────────┤
│          │                                                  │
│ Sidebar  │  Main Content (3-4 columns)                     │
│ (Full)   │  - Stats cards in grid                          │
│          │  - Charts side by side                          │
│          │  - Tables full width                            │
│          │                                                  │
└──────────┴──────────────────────────────────────────────────┘

Tablet (768px - 1024px)
┌─────────────────────────────────────────────────────────────┐
│ Navbar                                                      │
├────┬────────────────────────────────────────────────────────┤
│ S  │                                                        │
│ i  │  Main Content (2 columns)                             │
│ d  │  - Stats cards in 2 columns                           │
│ e  │  - Charts stacked                                     │
│    │  - Tables scrollable                                  │
│    │                                                        │
└────┴────────────────────────────────────────────────────────┘

Mobile (375px - 767px)
┌─────────────────────────────────────────┐
│ Navbar (Hamburger)                      │
├─────────────────────────────────────────┤
│                                         │
│  Main Content (1 column)                │
│  - Stats cards stacked                  │
│  - Charts full width                    │
│  - Tables horizontal scroll             │
│  - Touch-optimized buttons              │
│                                         │
└─────────────────────────────────────────┘
```

## 🚀 Deployment Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      PRODUCTION                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Vercel / Netlify CDN                                  │ │
│  │ - Static assets                                       │ │
│  │ - Global distribution                                 │ │
│  │ - HTTPS/SSL                                           │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ React Application                                     │ │
│  │ - Optimized build                                     │ │
│  │ - Code splitting                                      │ │
│  │ - Lazy loading                                        │ │
│  └───────────────────────────────────────────────────────┘ │
│                          │                                  │
│                          ▼                                  │
│  ┌───────────────────────────────────────────────────────┐ │
│  │ Supabase Cloud                                        │ │
│  │ - PostgreSQL (managed)                                │ │
│  │ - Auth (managed)                                      │ │
│  │ - Realtime (managed)                                  │ │
│  │ - Storage (managed)                                   │ │
│  │ - Automatic backups                                   │ │
│  └───────────────────────────────────────────────────────┘ │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

**This system is designed for**:
- ✅ Scalability
- ✅ Security
- ✅ Performance
- ✅ Real-time updates
- ✅ Multi-branch operations
- ✅ Role-based access

**Ready for**: Production deployment 🚀
